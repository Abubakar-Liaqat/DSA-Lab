#include <iostream>
using namespace std;
template <typename t>
void selectionSort(t& arr)
{
    int n = (sizeof(arr) / sizeof(arr[0]));
	{
    for (int i = 0; i < n - 1; i++) {
        int index = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[index]) {
                index = j;
            }
        }
        swap(arr[i], arr[index]);
    }
    }
	 
}

template<typename type>
void printArray(type& arr)
{
    int size = (sizeof(arr) / sizeof(arr[0]));
    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << "  ";
    }
}

int main() {
    // Test with an integer array of size 5
    int intArray[5] = { 64, 25, 12, 22, 11 };
    cout << "Original integer array: ";
    printArray(intArray);
    selectionSort(intArray);
    cout << "Sorted integer array: ";
    printArray(intArray);
    // Test with a string array of size 4
    string stringArray[4] = { "apple", "orange", "banana", "grape" };
    cout << "\nOriginal string array: ";
    printArray(stringArray);
    selectionSort(stringArray);
    cout << "Sorted string array: ";
    printArray(stringArray);
    return 0;
}