#include<iostream>
using namespace std;

// Macro to get the size of the array
#define SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

// Binary search function
template <typename type>
int binarySearch(type arr[], type key)
{
    int size = SIZE(arr);  // Get the size of the array using the macro
    int left = 0;
    int right = size - 1;  // Use the size calculated

    while (left <= right)
    {
        int mid = left + (right - left) / 2;

        if (arr[mid] == key)
            return mid;

        if (arr[mid] < key)
            left = mid + 1;
        else
            right = mid - 1;
    }

    return -1;  // If the element was not found
}

template<typename type1>
void printSearchResult(int index, type1 key)
{
    if (index != -1)
        cout << key << " found at index " << index << endl;
    else
        cout << key << " not found." << endl;
}

int main() {
    // Test with an integer array (sorted) of size 5
    int intArray[5] = { 11, 12, 22, 25, 64 };
    int intKey = 22;
    int intIndex = binarySearch(intArray, intKey);
    printSearchResult(intIndex, intKey);

    // Test with a float array (sorted) of size 4
    float floatArray[4] = { 0.57, 1.62, 2.71, 3.14 };
    float floatKey = 2.71;
    int floatIndex = binarySearch(floatArray, floatKey);
    printSearchResult(floatIndex, floatKey);

    // Test with a string array (sorted) of size 4
    string stringArray[4] = { "apple", "banana", "grape", "orange" };
    string stringKey = "grape";
    int stringIndex = binarySearch(stringArray, stringKey);
    printSearchResult(stringIndex, stringKey);

    return 0;
}
