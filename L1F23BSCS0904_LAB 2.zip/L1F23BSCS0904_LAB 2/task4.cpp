#include <iostream>
using namespace std;

 void rotateArray(int* arr, int n, int k) {
     k = k % n;

     int* temp = new int[n];

     for (int i = 0; i < n; i++) {
        *(temp + ((i + k) % n)) = *(arr + i);
    }

     for (int i = 0; i < n; i++) {
        *(arr + i) = *(temp + i);
    }

     delete[] temp;
}

 void printArray(int* arr, int n) {
    for (int i = 0; i < n; i++) {
        cout << *(arr + i) << " ";
    }
    cout << endl;
}

int main() {
    int n, k;

     cout << "Enter the size of the array: ";
    cin >> n;

    cout << "Enter the number of positions to rotate: ";
    cin >> k;

     int* arr = new int[n];

     cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++) {
        cin >> *(arr + i);
    }

    cout << "Original array: ";
    printArray(arr, n);

     rotateArray(arr, n, k);

    cout << "Array after rotation: ";
    printArray(arr, n);

     delete[] arr;

    return 0;
}
