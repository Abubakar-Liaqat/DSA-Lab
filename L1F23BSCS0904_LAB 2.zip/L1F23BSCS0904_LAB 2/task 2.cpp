#include <iostream>
using namespace std;

void SaddlePoint(int arr[][3], int rows, int cols) {
  
    for (int i = 0; i < rows; i++) {
        
        int min = arr[i][0];
        int minCol = 0;

        for (int j = 1; j < cols; j++) {
            if (arr[i][j] < min) {
                min = arr[i][j];
                minCol = j;
            }
        }
        bool found = true;
        for (int k = 0; k < rows; k++) {
            if (arr[k][minCol] > min) {
                found = false;
                break;
            }
        }
        if (found) {
            cout << "Saddle point found at (" << i << ", " << minCol << ")\n";
            return;
        }
    }

    cout << "No saddle point found.\n";
}

int main() {
    int arr[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {16, 16, 10}
    };

    SaddlePoint(arr, 3, 3);

    return 0;
}
