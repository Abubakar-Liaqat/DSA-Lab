#include<iostream>
using namespace std;
void find2ndlargest(int* arr,int size)
{
	int* ptr = arr;
	int max = *(ptr);
	int max2 = -1;//setting it to low so if not found then a different promtp
	for (int i = 0; i < size; i++)
	{
		if (max < *(ptr + i))
		{
			max2 = max;
			max = *(ptr + i);
			
		}
	}
	cout << "THE SECOND MAXIMUM IS : " << max2;


}
int main()
{
	int arr[5] = { 1,2,3,4,5 };
	find2ndlargest(arr, 5);
}