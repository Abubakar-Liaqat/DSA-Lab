#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
	Node* previous;
	Node(int d = 0)
	{
		data = d;
		next = previous = nullptr;
	}
};
class DoublyADP
{
public:
	virtual void insert_beg(int d) = 0;
	virtual void insert_end(int d) = 0;
	virtual void del_by_val(int d) = 0;
	virtual void display() = 0;
};
class Doubly :public DoublyADP
{
	Node* head;
	Node* tail;
public:
	Doubly()
	{
		head = tail = nullptr;
	}
	void addNode(int d)
	{
		Node* temp = new Node(d);
		if (head == nullptr)
		{
			head = tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->previous = tail;
			tail = temp;

		}
	}
	void insert_beg(int d)
	{
		Node* temp = new Node(d);
		if (head != NULL) {
			head->previous = temp;
			temp->next = head;
			head = temp;
		}
		else
		{
			head = temp;
			tail = temp;
		}
	}
	void insert_end(int d)
	{
		Node* temp = new Node(d);
		if (head == NULL) {
			head = tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->previous = tail;
			tail = temp;
		}
	}
	void del_by_val(int d)
	{
		Node* temp = head;
		if (head->data == d)
		{

			Node* temp = head->next;
			delete head;
			temp->previous = NULL;
			head = temp;
			return;
		}
		else if (tail->data == d)
		{
			Node* temp = tail->previous;
			delete tail;
			temp->next = NULL;
			tail = temp;
			return;
		}
		while (temp->next->data != d)
		{
			temp = temp->next;
		}
		Node* temp2 = temp->next;
		temp->next = temp2->next;
		temp2->next->previous = temp;
		delete temp2;
	}

	void display()
	{
		Node* temp = tail;
		while (temp != NULL)
		{
			cout << temp->data << "->";
			temp = temp->previous;
		}
		cout << "NULL\n";
	}

};
int main()
{
	Doubly d2;
	DoublyADP* d = &d2;
	d->insert_beg(1);
	d->insert_beg(2);
	d->insert_beg(3);
	d->insert_end(1212);
	d->insert_end(147);
	d->display();
	d->del_by_val(1212);
	d->display();


}

