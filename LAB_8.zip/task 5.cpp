#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string studentName;
    int studentPriority;
    string taskType;
    Node* next;
    Node* previous;

    Node(string n, int p, string t) {
        studentName = n;
        studentPriority = p;
        taskType = t;
        next = nullptr;
        previous = nullptr;
    }
};

class StudentList {
public:
    Node* start;
    Node* end;

    StudentList() {
        start = nullptr;
        end = nullptr;
    }

    void addByPriority(string name, int priority, string task) {
        Node* newNode = new Node(name, priority, task);

        if (start == nullptr) {
            start = end = newNode;
            return;
        }

        Node* current = start;

        while (current != nullptr && current->studentPriority >= priority) {
            current = current->next;
        }

        if (current == nullptr) {
            end->next = newNode;
            newNode->previous = end;
            end = newNode;
        }
        else if (current == start) {
            newNode->next = start;
            start->previous = newNode;
            start = newNode;
        }
        else {
            newNode->next = current;
            newNode->previous = current->previous;
            current->previous->next = newNode;
            current->previous = newNode;
        }
    }

    void printList() {
        Node* ptr = start;
        while (ptr != nullptr) {
            cout << ptr->studentName << " , Priority: " << ptr->studentPriority << " , Status: " << ptr->taskType << endl;
            ptr = ptr->next;
        }
        cout << endl;
    }

    void deleteByName(string name) {
        if (start == nullptr) return;

        if (start->studentName == name) {
            Node* temp = start;
            start = start->next;
            if (start != nullptr)
                start->previous = nullptr;
            delete temp;
            cout << "Head Changed" << endl;
            return;
        }

        if (end->studentName == name) {
            Node* temp = end;
            end = end->previous;
            if (end != nullptr)
                end->next = nullptr;
            delete temp;
            cout << "Tail Changed" << endl;
            return;
        }

        Node* current = start;
        while (current != nullptr) {
            if (current->studentName == name) {
                current->previous->next = current->next;
                current->next->previous = current->previous;
                delete current;
                return;
            }
            current = current->next;
        }
    }

    void modifyPriority(string name, int newPriority) {
        Node* temp = start;
        while (temp != nullptr) {
            if (temp->studentName == name) {
                string currentTask = temp->taskType;
                deleteByName(name);
                addByPriority(name, newPriority, currentTask);
                return;
            }
            temp = temp->next;
        }
    }

    void totalStudents() {
        Node* temp = start;
        int count = 0;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        cout << "Total Students are: " << count << endl;
    }

    void removeFront() {
        if (start == nullptr) {
            cout << "No student" << endl;
            return;
        }

        Node* temp = start;
        start = start->next;
        if (start != nullptr)
            start->previous = nullptr;
        delete temp;

        cout << "Front Student Removed!" << endl;
    }
};

int main() {
    StudentList dsaCourse, dbCourse;

    // Inserting DSA students
    string dsaNames[] = { "A", "B", "C", "D", "E" };
    int dsaPriorities[] = { 3, 5, 2, 1, 4 };
    string dsaTasks[] = { "Research", "Assignment", "Quiz", "Quiz2", "Quiz3" };

    cout << "DSA :" << endl;
    for (int i = 0; i < 5; i++) {
        dsaCourse.addByPriority(dsaNames[i], dsaPriorities[i], dsaTasks[i]);
    }
    dsaCourse.printList();

     
    dsaCourse.modifyPriority("B", 6);
    dsaCourse.printList();

     
    dsaCourse.deleteByName("B");
    dsaCourse.printList();

    
    dsaCourse.totalStudents();

     
    dsaCourse.removeFront();
    dsaCourse.printList();


     
    
    return 0;
}

