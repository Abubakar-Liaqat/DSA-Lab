#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
	Node* previous;
	Node(int d = 0)
	{
		data = d;
		next = previous = nullptr;
	}
};

class Doubly
{
	Node* head;
	Node* tail;
public:
	Doubly()
	{
		head = tail = nullptr;
	}
	void addNode(int d)
	{
		Node* temp = new Node(d);
		if (head == nullptr)
		{
			head = tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->previous = tail;
			tail = temp;

		}
	}
	void display()
	{
		Node* temp = head;
		while (temp != NULL)
		{
			cout << temp->data << "->";
			temp = temp->next;
		}
		cout << "NULL\n";
	}

};
int main()
{
	Doubly d;
	d.addNode(1);
	d.addNode(2);
	d.addNode(3);
	d.display();

}