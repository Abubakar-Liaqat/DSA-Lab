#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
	Node* previous;
	Node(int d = 0)
	{
		data = d;
		next = previous = nullptr;
	}
};
class DoublyADP
{
public:

	virtual void insert_beg(int d) = 0;
	virtual void insert_end(int d) = 0;
	virtual void del_by_val(int d) = 0;
	virtual void display() = 0;
	virtual void insert_pos() = 0;
	virtual void del_pos() = 0;
	virtual void search() = 0;
	virtual int length() = 0;
};
class Doubly :public DoublyADP
{
	Node* head;
	Node* tail;
public:
	Doubly()
	{
		head = tail = nullptr;
	}
	void addNode(int d)
	{
		Node* temp = new Node(d);
		if (head == nullptr)
		{
			head = tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->previous = tail;
			tail = temp;

		}
	}
	void insert_beg(int d)
	{
		Node* temp = new Node(d);
		if (head != NULL) {
			head->previous = temp;
			temp->next = head;
			head = temp;
		}
		else
		{
			head = temp;
			tail = temp;
		}
	}
	void insert_end(int d)
	{
		Node* temp = new Node(d);
		if (head == NULL) {
			head = tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->previous = tail;
			tail = temp;
		}
	}
	void del_by_val(int d)
	{
		Node* temp = head;
		if (head->data == d)
		{

			Node* temp = head->next;
			delete head;
			temp->previous = NULL;
			head = temp;
			return;
		}
		else if (tail->data == d)
		{
			Node* temp = tail->previous;
			delete tail;
			temp->next = NULL;
			tail = temp;
			return;
		}
		while (temp->data != d)
		{
			temp = temp->next;
		}
		temp = temp->previous;
		Node* temp2 = temp->next;
		temp->next = temp2->next;
		temp2->next->previous = temp;
		delete temp2;
	}

	void display()
	{
		Node* temp = head;
		while (temp != NULL)
		{
			cout << temp->data << "->";
			temp = temp->next;
		}
		cout << "NULL\n";
	}
	void insert_pos()
	{
		int d;
		cout << "\nENTER VALUE : ";
		cin >> d;
		int pos;
		cout << "ENTER POSITION WHERE YOU WANT TO ADD : ";
		cin >> pos;
		if (pos == 0)
		{
			insert_beg(d);
		}
		else if (pos == length() - 1)
		{
			insert_end(d);
		}
		else if (pos > length())
		{
			cout << "THE SIZE IS GREATER THEN THE LIST SIZE ";
			return;
		}
		else {
			Node* temp = head;
			for (int i = 1; i < pos - 1; i++)
			{
				temp = temp->next;
			}
			Node* newNode = new Node(d);
			newNode->previous = temp;
			newNode->next = temp->next;
			temp->next = newNode;
		}
	}
	void del_pos()
	{
		int pos;
		cout << "ENTER POSITION WHERE YOU WANT TO DELETE  : ";
		cin >> pos;
		Node* temp = head;
		for (int i = 1; i < pos - 1; i++)
		{
			temp = temp->next;
		}
		Node* temp2 = temp->next;
		temp->next = temp2->next;
		temp2->next->previous = temp;
		delete temp2;

	}
	void search()
	{
		Node* temp = head;
		int d;
		cout << "ENTER NUMBER YOU WANT TO SEARCH : ";
		cin >> d;
		int count = 0;
		while (temp != NULL)
		{
			if (temp->data == d)
			{
				cout << d << " found at node # " << count + 1;
				break;
			}
			else
			{
				count++;
				temp = temp->next;
			}
		}
	}
	int length()
	{
		Node* temp = head;
		int count = 0;
		while (temp != NULL)
		{
			count++;
			temp = temp->next;
		}
		return count;
	}

};
void menu(DoublyADP* list)
{
	int choice;
	while (true)
	{
		cout << "\n--- Doubly Linked List Menu ---\n";
		cout << "1. Add Node at End\n";
		cout << "2. Insert at Beginning\n";
		cout << "3. Insert at End\n";
		cout << "4. Insert at Position\n";
		cout << "5. Delete by Value\n";
		cout << "6. Delete by Position\n";
		cout << "7. Search\n";
		cout << "8. Display\n";
		cout << "9. Length\n";
		cout << "0. Exit\n";
		cout << "Enter your choice: ";
		cin >> choice;

		int val;

		switch (choice)
		{
		case 1:
			cout << "Enter value to add at end: ";
			cin >> val;

			list->insert_end(val);
			break;
		case 2:
			cout << "Enter value to insert at beginning: ";
			cin >> val;
			list->insert_beg(val);
			break;
		case 3:
			cout << "Enter value to insert at end: ";
			cin >> val;
			list->insert_end(val);
			break;
		case 4:
			list->insert_pos();
			break;
		case 5:
			cout << "Enter value to delete: ";
			cin >> val;
			list->del_by_val(val);
			break;
		case 6:
			list->del_pos();
			break;
		case 7:
			list->search();
			break;
		case 8:
			list->display();
			break;
		case 9:
			cout << "Length of list: " << list->length() << "\n";
			break;
		case 0:
			cout << "Exiting...\n";
			return;
		default:
			cout << "Invalid choice! Try again.\n";
		}
	}
}

int main()
{
	DoublyADP* list = new Doubly();
	menu(list);
	delete list;
	return 0;
}