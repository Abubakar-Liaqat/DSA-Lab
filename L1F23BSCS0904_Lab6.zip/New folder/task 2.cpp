#include<iostream>
using namespace std;
class myCarStack
{
private:
	int capacity;
	int top;
	int* arr;
public:
	myCarStack()
	{
		capacity = 8;
		top = -1;
		arr = new int[capacity];
	}
	void push(int num)
	{
		if (top == capacity - 1)
		{
			cout << "STACK IS FULL ! ";
			return;
		}
		else
		{
			
			arr[top+1] = num;
			top++;
		}
	}
	int getTop()
	{
		return top;
	}
	void display()
	{
		for (int i = top; i >= 0; i--)
		{
			cout << arr[i] << " ";
		}
	}
	int pop()
	{
		if (top == -1)
		{
			cout << "CANNOT POP EMPTY STACK ";
			return int();
		}
		else
		{
			top--;
			return arr[top + 1];
		}
	}

	int pop_by_num (int num)
	{
		if (top == -1)
		{
			cout << "UNABLE TO POP FROM EMPTY STACK ! ";
			return int();
		}
		else
		{
			if (num == arr[top])
			{
				 
				pop();
			}
			else
			{
				myCarStack temp;
				int carindex = 0;
				bool found = 0;
				for (int i = 0; i < top; i++)
				{
					if(arr[i]!=num)
					{
						found = 0;
						carindex++;
						temp.push(arr[i]);
					}
					else if (arr[i] == num)
					{
						found = 1;
						break;
					}
				}
				int poppedcar = arr[carindex-1];
				
				 if(found==1)
				 {
					 for (int i = temp.getTop() + 1; i < top; i++)
					 {
						 temp.push(arr[carindex + 1]);
						 carindex++;
					 }

					 for (int i = 0; i < top; i++)
					 {
						 arr[i] = temp.arr[i];
					 }
					 top--;

					 return poppedcar;
				 }
				 else if (found == 0)
				 {
					 cout << "NO SUCH CAR IN PARKING LOT !! ";
					 return int();
				 }

			}
		}
	}
	void total_cars()
	{
		cout << "TOTAL PARKED CARS : " << getTop()+1;
	}
	void search()
	{
		int num;
		int index = 0;
		cout << "ENTER CAR NUMBER TO SEARCH : ";
		cin >> num;
		for (int i = top; i >= 0; i++)
		{
			if (arr[i] == num)
			{
				cout << "YOUR CAR IS AT LOT NUMBER  : " << index << endl;
			}
			else
			{
				index++;
			}
		}
	}
};
void menu()
{
	myCarStack car;
	int choice;

	do {
		cout << "\n\n--- PARKING LOT MENU ---";
		cout << "\n1. Park Car (Push)";
		cout << "\n2. Remove Last Car (Pop)";
		cout << "\n3. Remove Specific Car";
		cout << "\n4. Display All Cars";
		cout << "\n5. Search for a Car";
		cout << "\n6. Show Total Cars";
		cout << "\n7. Exit";
		cout << "\nEnter your choice: ";
		cin >> choice;

		switch (choice)
		{
		case 1:
		{
			int carNum;
			cout << "Enter car number to park: ";
			cin >> carNum;
			car.push(carNum);
			break;
		}
		case 2:
		{
			int removed = car.pop();
			cout << "Removed car number: " << removed << endl;
			break;
		}
		case 3:
		{
			int carNum;
			cout << "Enter car number to remove: ";
			cin >> carNum;
			int removed = car.pop_by_num(carNum);
			if (removed)
				cout << "Removed car number: " << removed << endl;
			 
			break;
		}
		case 4:
		{
			cout << "Cars in parking (top to bottom): ";
			car.display();
			cout << endl;
			break;
		}
		case 5:
		{
			car.search();
			break;
		}
		case 6:
		{
			car.total_cars();
			break;
		}
		case 7:
		{
			cout << "Exiting program. Goodbye!\n";
			break;
		}
		default:
		{
			cout << "Invalid choice. Try again.\n";
		}
		}
	} while (choice != 7);
}

int main()
{
	menu();
	return 0;
}